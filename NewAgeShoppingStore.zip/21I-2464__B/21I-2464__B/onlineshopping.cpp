#include<iostream>
#include<string.h>
#include<fstream>
#include "easypaisa.cpp"
using namespace std;

class onlineshopping {

public:

    string totalcart;
    Payment p;

    int count;

    onlineshopping() {
        count = 0;
    }

    void addtoCart(string item) {
        int comacount = 0;
        string price = "";
        for (int i = 0; item[i] != '\0'; i++)
        {
            if (item[i] == ',')
            {
                i++; comacount++;
            }

            if (comacount == 2)
            {
                price += item[i];
            }
        }

        int intprice =std:: atoi(price.c_str());
        totalcart += item;
        p.totalamount += intprice;
        count++;
    }

    void displaycart() {

        cout << "item count:" << count << " price:" << p.totalamount << endl;
        cout << totalcart << endl;
    }

};