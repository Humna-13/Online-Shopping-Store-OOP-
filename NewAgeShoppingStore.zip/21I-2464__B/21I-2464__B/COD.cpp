#include<iostream>
#include<string.h>
#include<fstream>
#include "payment.cpp"
using namespace std;


class COD : public Payment {


public:

    void processPayment() {

        totalamount += 30;

        cout << "total bill for cash on delivery with delivery tax added:" << totalamount << endl;

    }

};