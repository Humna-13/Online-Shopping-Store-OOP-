#include<iostream>
#include<fstream>
#include<cstring>
//#include <bits/stdc++.h>
#include<string>
using namespace std;

string convertToString(char* a, int size)
{
    int i;
    string s = "";
    for (i = 0; a[i] != '\0'; i++) {
        s = s + a[i];
    }
    return s;
}
class productcatalogue
{
public:

    char type[20];
    char name[20];
    int typelen = 0, namelen = 0;
    int price;

    void getdata(productcatalogue pr)
    {
        char n[20];
        int p;
        cout << "Enter name" << endl;
        cin.getline(n, 19);
        cout << "Enter price" << endl;
        cin >> p;
        for (int i = 0; n[i] != '\0'; i++)
        {
            pr.name[i] = n[i];
            namelen++;
        }

        pr.price = p;
        pr.name[namelen] = '\0';
        pr.type[typelen] = '\0';
        //cout<<"type:"<<pr.type<<endl;
        cout << "name:" << pr.name << endl;
        cout << "price:" << pr.price << endl;


    }
    void updateproductcatalogue()
    {
        char t[20], n[20];
        int p;
        cout << "Enter the type of product food/personal hygeine/household cleaning" << endl;
        cin >> t;
        cout << "Enter name" << endl;
        cin >> n;
        cout << "Enter price" << endl;
        cin >> p;
        productcatalogue pro;
        for (int i = 0; t[i] != '\0'; i++)
        {
            pro.type[i] = t[i];
            typelen++;
        }
        for (int i = 0; n[i] != '\0'; i++)
        {
            pro.name[i] = n[i];
            namelen++;
        }
        pro.price = p;
        pro.name[namelen] = '\0';
        pro.type[typelen] = '\0';
        cout << "type:" << pro.type << endl;
        cout << "name:" << pro.name << endl;
        cout << "price:" << pro.price << endl;


        ofstream file("prodc.bin", ios::binary | ios::app | ios::in);
        if (!file.is_open())
        {
            cout << "ErROR" << endl;
        }
        else
        {
            file.write((char*)&pro, sizeof(productcatalogue));
            //file.put('\n');
            file.close();
        }
    }

    void displayproducts()
    {
        productcatalogue obj;
        ifstream file("prodc.bin", ios::binary | ios::out);

        while (file.read((char*)&obj, sizeof(obj))) {
            cout << obj.type << "," << obj.name << "," << obj.price << "\n";
        }

        file.close();
    }

    void editproducts()
    {
        char n[20];
        string type;
        cout << "enter type of product you want to edit\n";
        cin >> type;
        int p;
        long pos;
        productcatalogue pro;
        fstream f("prodc.bin", ios::in | ios::out | ios::binary);
        while (f.read((char*)&pro, sizeof(pro)))
        {
            pos = f.tellg();
            if (pro.type == type)
            {
                f.seekg(pos);

                cout << "Enter name" << endl;
                cin >> n;
                cout << "Enter price" << endl;
                cin >> p;
                for (int i = 0; n[i] != '\0'; i++)
                {
                    pro.name[i] = n[i];
                    namelen++;
                }

                pro.price = p;
                pro.name[namelen] = '\0';
                //pro.type[typelen]='\0';
                //cout<<"type:"<<pr.type<<endl;
                cout << "name:" << pro.name << endl;
                cout << "price:" << pro.price << endl;
                f.write((char*)&pro, sizeof(pro));
                f.close();
                break;
            }
        }




    }
    string search(string name) {

        productcatalogue obj;
        ifstream file("prodc.bin", ios::binary | ios::out);
        string str;
        while (file.read((char*)&obj, sizeof(obj))) {
            if (obj.name == name)
                str += convertToString(obj.type, 20) + ',' + convertToString(obj.name, 20) + ',' + to_string(obj.price) + '\n';
        }

        file.close();

        return str;
    }

    void deleteproduct()
    {
        int choice, flag;
        char t[20], n[20];
        int p;
        productcatalogue pro;
        cout << "Write 1 for deleting type,2 for name,2 for price" << endl;
        cin >> choice;

        fstream file;
        long pos;

        file.open("prodc.bin", ios::in | ios::binary | ios::out);

        productcatalogue prod;
        if (choice == 1)
        {
            cout << "Enter type" << endl;
            cin.getline(t, 19);
            /*   for(int i=0;t[i]!='\0';i++)
               {
                   pro.type[i]=t[i];
                   typelen++;
               }
               pro.type[typelen]='\0';*/

            while (file.read((char*)&pro, sizeof(pro)))
            {
                pos = file.tellg();
                if (pro.type == t)
                {
                    cout << "Found" << endl;
                    file.seekg(pos);
                }
                for (int i = 0; t[i] != '\0'; i++)
                {
                    pro.type[i] = '\0';
                }
                file.write((char*)&pro, sizeof(pro));
                file.close();
                break;
            }
        }
        else if (choice == 2)
        {
            cout << "Enter name" << endl;
            cin.getline(n, 19);
            while (file.read((char*)&pro, sizeof(pro)))
            {
                pos = file.tellg();
                if (pro.name == n)
                {
                    cout << "Found" << endl;
                    file.seekg(pos);
                }
                for (int i = 0; n[i] != '\0'; i++)
                {
                    pro.name[i] = '\0';
                }
                file.write((char*)&pro, sizeof(pro));
                file.close();
                break;
            }

        }
        else if (choice == 3)
        {
            cout << "Enter price" << endl;
            cin >> p;
            while (file.read((char*)&pro, sizeof(pro)))
            {
                pos = file.tellg();
                if (pro.price == p)
                {
                    cout << "Found" << endl;
                    file.seekg(pos);
                }
                pro.price = '\0';
                file.write((char*)&pro, sizeof(pro));
                file.close();
                break;
            }
        }


    }
};
/*
int main()
{
    productcatalogue obj;
    obj.updateproductcatalogue();
    //obj.deleteproduct();
     obj.displayproducts();
   obj.editproducts();
    //obj.deleteproduct();

     obj.displayproducts();
}*/