#include<iostream>
#include<fstream>
#include "person.cpp"
#include "inventory.cpp"
using namespace std;

class manager : public Person
{
public:
    inventory pc;

    void login()
    {
        filename = "mnager.txt";
        Person::login();

    }

    void displayMenu() {
        int op;
        cout << "1)search and view item\n2)Manage Inventory\n";
        cin >> op;

        if (op == 2) {
            int op2;
            cout << "1)add item in inventory\n2)edit item in inventory\n3)remove item in inventory\n";
            cin >> op2;
            if (op2 == 1)
                pc.updateproductcatalogue();
            else if (op2 == 2)
                pc.editproducts();
            else
                pc.deleteproduct();
        }
        else {
            pc.search();
        }
    }

};