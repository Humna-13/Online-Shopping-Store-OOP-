#include<iostream>
#include<string.h>
#include<fstream>
using namespace std;


class Payment {

public:

    string type;
    int totalamount = 0;

    Payment() {

    }

    void processPayment() {


    }
    void chargeforCOD() {
        totalamount += 30;
    }
};