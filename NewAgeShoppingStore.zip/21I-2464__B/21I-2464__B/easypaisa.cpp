#include<iostream>
#include<string.h>
#include<fstream>
#include "debitcard.cpp"
using namespace std;


class easypaisa : public Payment {

public:
    void processPayment() {
        string accountno, pin;
        cout << "enter Easypaisa account number\n";
        cin >> accountno;
        cout << "enter pin\n";
        cin >> accountno;

        cout << "amount:" << totalamount << "deducted from your easypaisa wallet\n";
    }
};