#include<iostream>
#include<fstream>
#include "manager.cpp"
#include "pdc.cpp"
#include "storesandusers.cpp"
#include<iomanip>

using namespace std;

class admin : public Person
{

public:
    storesandusers st;
    productcatalogue pc;
    bool end = false;
    clock_t start;
    void login()
    {
        filename = "admin.txt";
        Person::login();

    }

    manager registerManager()
    {
        char user[20];
        char password[20];
        manager m;
        cout << "Enter username" << endl;
        cin >> user;
        m.setusername(user);
        cout << "Enter password" << endl;
        cin >> password;
        m.setpass(password);
        ofstream fout;
        ifstream fin;
        fin.open("mnager.txt");
        fout.open("mnager.txt", ios::app);
        fout << user << "," << password << "\n";

        return m;
    }

    void displayMenu() {
        int op;
        cout << "1)Manager stores and users\n2)Manage Product catalogue\n";
        cin >> op;

        if (op == 2) {
            int op2;
            cout << "1)add item in catalogue\n2)edit item in catalogue\n3)remove item in catalogue\n";
            cin >> op2;
            if (op2 == 1)
                pc.updateproductcatalogue();
            else if (op2 == 2)
                pc.editproducts();
            else
                pc.deleteproduct();
        }
        else {
            cout << "store list:\n";
            st.viewstores();
        }
    }

    void storesimulation() {

        clock_t endd;



        if (end) {
            endd = clock();
            double time_taken = double(endd - start) / double(CLOCKS_PER_SEC);
            cout << "Time taken by customer is : " << fixed
                << time_taken << setprecision(5);
            cout << " sec " << endl;

        }
    }

};
/*
int main()

{
    admin ad;
    //ad.login();
   ad.registerManager();
}*/