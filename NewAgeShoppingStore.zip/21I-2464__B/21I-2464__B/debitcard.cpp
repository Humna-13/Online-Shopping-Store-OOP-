#include<iostream>
#include<string.h>
#include<fstream>
#include "COD.cpp"
using namespace std;


class debitcard : public Payment {



public:

    void processPayment() {
        string accountno, pin;
        cout << "enter debit account number\n";
        cin >> accountno;
        cout << "enter pin\n";
        cin >> accountno;

        cout << "amount:" << totalamount << "deducted from your debit wallet\n";
    }
};