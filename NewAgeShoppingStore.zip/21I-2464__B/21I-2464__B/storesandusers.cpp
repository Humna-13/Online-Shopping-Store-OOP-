#include<string>
#include<iostream>
#include<fstream>
using namespace std;

class storesandusers {

    string storeid;
public:
    storesandusers() {

    }

    void viewstores() {
        ifstream readfile("stores.txt");
        string line;
        while (getline(readfile, line)) {

            cout << line << endl;
        }

    }
};