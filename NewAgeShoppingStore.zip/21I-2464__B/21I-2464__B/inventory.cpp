#include<iostream>
#include<string.h>
#include<fstream>
using namespace std;

class inventory {


public:

    char type[20];
    char name[20];
    int typelen = 0, namelen = 0;
    int price;

    void getdata(inventory pr)
    {
        char n[20];
        int p;
        cout << "Enter name" << endl;
        cin.getline(n, 19);
        cout << "Enter price" << endl;
        cin >> p;
        for (int i = 0; n[i] != '\0'; i++)
        {
            pr.name[i] = n[i];
            namelen++;
        }

        pr.price = p;
        pr.name[namelen] = '\0';
        pr.type[typelen] = '\0';
        //cout<<"type:"<<pr.type<<endl;
        cout << "name:" << pr.name << endl;
        cout << "price:" << pr.price << endl;


    }
    void updateproductcatalogue()
    {
        char t[20], n[20];
        int p;
        cout << "Enter the type of product food/personal hygeine/household cleaning" << endl;
        cin >> t;
        cout << "Enter name" << endl;
        cin >> n;
        cout << "Enter price" << endl;
        cin >> p;
        inventory pro;
        for (int i = 0; t[i] != '\0'; i++)
        {
            pro.type[i] = t[i];
            typelen++;
        }
        for (int i = 0; n[i] != '\0'; i++)
        {
            pro.name[i] = n[i];
            namelen++;
        }
        pro.price = p;
        pro.name[namelen] = '\0';
        pro.type[typelen] = '\0';
        cout << "type:" << pro.type << endl;
        cout << "name:" << pro.name << endl;
        cout << "price:" << pro.price << endl;


        ofstream file("inventory.bin", ios::binary | ios::app | ios::in);
        if (!file.is_open())
        {
            cout << "ErROR" << endl;
        }
        else
        {
            file.write((char*)&pro, sizeof(inventory));
            //file.put('\n');
            file.close();
        }
    }

    void displayproducts()
    {
        inventory obj;
        ifstream file("inventory.bin", ios::binary | ios::out);

        while (file.read((char*)&obj, sizeof(obj))) {
            cout << obj.type << "," << obj.name << "," << obj.price << "\n";
        }

        file.close();
    }

    void search()
    {
        inventory obj; string n; bool found = false;
        ifstream file("inventory.bin", ios::binary | ios::out);
        cout << "name of item you want to search\n";
        cin >> n;
        while (file.read((char*)&obj, sizeof(obj))) {
            if (obj.name == n)
            {
                found = true; cout << obj.type << "," << obj.name << "," << obj.price << "\n";
            }
        }

        file.close();
        if (!found) {
            cout << "not found\n";
        }
    }

    void editproducts()
    {
        char n[20];
        string type;
        cout << "enter type of product you want to edit\n";
        cin >> type;
        int p;
        long pos;
        inventory pro;
        fstream f("inventory.bin", ios::in | ios::out | ios::binary);
        while (f.read((char*)&pro, sizeof(pro)))
        {
            pos = f.tellg();
            if (pro.type == type)
            {
                f.seekg(pos);

                cout << "Enter name" << endl;
                cin >> n;
                cout << "Enter price" << endl;
                cin >> p;
                for (int i = 0; n[i] != '\0'; i++)
                {
                    pro.name[i] = n[i];
                    namelen++;
                }

                pro.price = p;
                pro.name[namelen] = '\0';
                //pro.type[typelen]='\0';
                //cout<<"type:"<<pr.type<<endl;
                cout << "name:" << pro.name << endl;
                cout << "price:" << pro.price << endl;
                f.write((char*)&pro, sizeof(pro));
                f.close();
                break;
            }
        }




    }

    void deleteproduct()
    {
        int choice, flag;
        char t[20], n[20];
        int p;
        inventory pro;
        cout << "Write 1 for deleting type,2 for name,2 for price" << endl;
        cin >> choice;

        fstream file;
        long pos;

        file.open("inventory.bin", ios::in | ios::binary | ios::out);

        inventory prod;
        if (choice == 1)
        {
            cout << "Enter type" << endl;
            cin.getline(t, 19);
            /*   for(int i=0;t[i]!='\0';i++)
               {
                   pro.type[i]=t[i];
                   typelen++;
               }
               pro.type[typelen]='\0';*/

            while (file.read((char*)&pro, sizeof(pro)))
            {
                pos = file.tellg();
                if (pro.type == t)
                {
                    cout << "Found" << endl;
                    file.seekg(pos);
                }
                for (int i = 0; t[i] != '\0'; i++)
                {
                    pro.type[i] = '\0';
                }
                file.write((char*)&pro, sizeof(pro));
                file.close();
                break;
            }
        }
        else if (choice == 2)
        {
            cout << "Enter name" << endl;
            cin.getline(n, 19);
            while (file.read((char*)&pro, sizeof(pro)))
            {
                pos = file.tellg();
                if (pro.name == n)
                {
                    cout << "Found" << endl;
                    file.seekg(pos);
                }
                for (int i = 0; n[i] != '\0'; i++)
                {
                    pro.name[i] = '\0';
                }
                file.write((char*)&pro, sizeof(pro));
                file.close();
                break;
            }

        }
        else if (choice == 3)
        {
            cout << "Enter price" << endl;
            cin >> p;
            while (file.read((char*)&pro, sizeof(pro)))
            {
                pos = file.tellg();
                if (pro.price == p)
                {
                    cout << "Found" << endl;
                    file.seekg(pos);
                }
                pro.price = '\0';
                file.write((char*)&pro, sizeof(pro));
                file.close();
                break;
            }
        }


    }


};