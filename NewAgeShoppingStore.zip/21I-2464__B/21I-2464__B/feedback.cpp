#include<iostream>
#include<string.h>
#include<fstream>

using namespace std;

class feedback {

    int rating;
    string review;

public:

    feedback() {

    }
    int getRating()
    {
        return rating;
    }


    void setRating(int rat)
    {
        rating = rat;
    }


    string getReview()
    {
        return review;
    }


    void setReview(string rev)
    {
        review = rev;
    }
};