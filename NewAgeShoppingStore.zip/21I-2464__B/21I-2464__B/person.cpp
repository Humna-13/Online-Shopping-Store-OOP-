#include<iostream>
#include<string>
#include <fstream>
using namespace std;

class Person {

public:
    int personid;
    char username[20];
    char pass[9];
    char name[20];
    char role;
    string filename = "";

    string  getFilename()
    {
        return this->filename;
    }


    void setFilename(string filename)
    {
        this->filename = filename;
    };

    Person()
    {

    }

    int getpersonid()
    {
        return personid;
    }

    void setpersonid(int id)
    {
        personid = id;
    }

    char* getusername()
    {
        return username;
    }

    void setusername(char user[])
    {
        for (int i = 0; i < strlen(user); i++)
        {
            username[i] = user[i];
        }

    }

    char* getpassword()
    {
        return pass;
    }

    void setpass(char password[])
    {
        for (int i = 0; i < strlen(password); i++)
        {
            pass[i] = password[i];
        }
    }

    char getRole()
    {
        return role;
    }
    void setrole(char roles)
    {
        role = roles;
    }

    char* getname()
    {
        return name;
    }
    void setname(char* nme)
    {
        for (int i = 0; i < strlen(nme); i++)
        {
            name[i] = nme[i];
        }
    }

    void login()
    {
        char user[20];
        char password[20];
        bool found = false;
        cout << "Enter username" << endl;
        cin >> user;

        cout << "Enter password" << endl;
        cin >> password;


        ifstream readfile(filename);
        string line;
        while (getline(readfile,line)) {

            cout << line << endl;
            string fuser = "", fpass = "";
            bool next = false;
            int commas = 0;
            for (int i = 0; line[i] != '\0'; i++) {
                if (commas == 2)
                    break;

                if (line[i] == ',')
                {
                    i++; next = true; commas++;
                }

                if (!next)
                    fuser += line[i];
                else
                    fpass += line[i];
            }
            //cout<<"extr:"<<fuser<<" "<<fpass<<endl;
            if ((user == fuser) && (password == fpass))
            {
                found = true; cout << "login successful\n"; setusername(user);  setpass(password); break;
            }


        }

        if (!found)
            cout << "error in login\n";
    }

    void displayMenu() {


    }





};
/*int main()
{
  Person obj;
  obj.login();
  string pass=obj.getpassword();
  string user=obj.getusername();
  cout<<pass<<endl<<user<<endl;

}*/