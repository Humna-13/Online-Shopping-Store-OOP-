#include<iostream>
#include "customer.cpp"
using namespace std;


int main() {

    int loginorsingup;
    cout << "--------------Welcome to New age grocery store------------------------\n";
    cout << "select \n1)Login\n2)Registeration\n";
    cin >> loginorsingup;

    if (loginorsingup == 1) {

        //---------------------LOGIN---------------------------------------------
        int cust_or_admin_or_manger;
        cout << "Login as\n1)Customer\n2)admin\n3)Manager\n";
        cin >> cust_or_admin_or_manger;

        if (cust_or_admin_or_manger == 1) {
            Customer c;
            admin a;
            c.login();
            a.start = clock();
            while (true) {

                c.displayMenu();
                char c;
                cout << "enter e to exit or c to continue\n";
                cin >> c;
                if (c == 'c')
                    cout << endl << endl << endl;
                else
                    break;

            }
            a.end = true;
            a.storesimulation();
        }
        else if (cust_or_admin_or_manger == 2) {
            admin a;
            while (true) {
                a.login();
                a.displayMenu();
                char c;
                cout << "enter e to exit or c to continue\n";
                cin >> c;
                if (c == 'c')
                    cout << endl << endl << endl;
                else
                    break;
            }
        }
        else {
            manager m;
            while (true) {
                m.login();
                m.displayMenu();
                char c;
                cout << "enter e to exit or c to continue\n";
                cin >> c;
                if (c == 'c')
                    cout << endl << endl << endl;
                else
                    break;
            }
        }

    }
    else {

        //---------------------Registeration---------------------------------------------
        int cust_or_admin_or_manger;
        cout << "Register as\n1)Customer\n2)Manager\n";
        cin >> cust_or_admin_or_manger;


        if (cust_or_admin_or_manger == 1) {
            Customer c;
            c.registeration();
            c.displayMenu();
        }
        else {
            admin a;
            manager m = a.registerManager();

            m.displayMenu();

        }

    }

}