#include "admin.cpp"
#include "onlineshopping.cpp"
#include "feedback.cpp"
class Customer : public Person {

    string gender;
    productcatalogue pc;
    string phononum;
    string address;
    string CNIC;



public:
    onlineshopping sp;

    Customer() {
        filename = "";
        gender = "";
        phononum = "";
        address = "";
        CNIC = "";
    }

    string getPhononum()
    {
        return this->phononum;
    }


    void setPhononum(string phononum)
    {
        this->phononum = phononum;
    };

    string getAddress()
    {
        return this->address;
    }


    void setAddress(string address)
    {
        this->address = address;
    }


    string getCNIC()
    {
        return this->CNIC;
    }

    void setCNIC(string CNIC)
    {
        this->CNIC = CNIC;
    }

    string getGender()
    {
        return this->gender;
    }


    void setGender(string gender)
    {
        this->gender = gender;
    };


    void login() {
        filename = "customer.txt";
        Person::login();
    }

    void registeration() {

        char user[20];
        char password[20];
        cout << "enter name\n";
        cin.getline(name, 19);
        cout << "Enter username" << endl;
        cin >> user;
        cout << "Enter cnic" << endl;
        cin >> CNIC;
        setusername(user);
        cout << "Enter password" << endl;
        cin >> password;
        while (true)
        {
            if (strlen(password) != 9) {
                cout << "Password must be 9 characters long\n";
                cin >> password;
            }
            int uppercasecount = 0, digitcount = 0;
            for (int i = 0; password[i] != '\0'; i++) {
                if (password[i] >= 'A' && password[i] <= 'Z')
                    uppercasecount++;
                if (password[i] >= '0' && password[i] <= '9')
                    digitcount++;
            }

            if (strlen(password) == 9 && uppercasecount >= 1 && digitcount >= 1)
                break;
            else
            {
                cout << "Password not good, Re Enter\n";
                cin >> password;
            }


        }


        setpass(password);

        ofstream fout;
        ifstream fin;
        fin.open("customer.txt");
        fout.open("customer.txt", ios::app);
        fout << username << "," << password << "\n";
    }

    void displayMenu() {

        int op;
        string name;

        cout << "1)add to cart\n2)checkout and payment\n";
        cin >> op;

        if (op == 1) {
            pc.displayproducts();
            cout << "enter name of item you want to add in cart\n";
            cin >> name;
            sp.addtoCart(pc.search(name));

        }
        else {
            int op2;
            cout << "enter payment method\n1)COD\n2)debit card\n3)Easypaisa\n";
            cin >> op2;

            if (op2 == 1) {
                COD c;
                c.type = "COD";
                c.totalamount = sp.p.totalamount;
                c.processPayment();
            }
            else if (op2 == 2) {
                debitcard c;
                c.type = "debit card";
                c.totalamount = sp.p.totalamount;
                c.processPayment();

            }
            else {
                easypaisa c;
                c.type = "easypaisa";
                c.totalamount = sp.p.totalamount;
                c.processPayment();

            }
            feedback f;
            int rat;
            string rev;
            cout << "Plz give feedback\n";
            cout << "enter rating out of 10\n";
            cin >> rat;
            cout << "enter rating out of 10\n";
            cin >> rev;
            f.setRating(rat);
            f.setReview(rev);


        }
    }

};
/*
int main(){
    Customer c;
    //c.registeration();
    //c.login();
    c.displayMenu();
    c.displayMenu();
    c.sp.displaycart();
}*/